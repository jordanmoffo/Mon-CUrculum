<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="php.css">
    <style type="text/css">
        material-icons {
            color: #fff;
            font-size: 20px !important;
            /* 24px preferred icon size */
        }

        a {
            text-decoration: none;
        }

        #btn {
            display: none;
        }

        .button-parent {
            display: flex;
        }

        .button {
            width: 50px;
            height: 50px;
            display: block;
            margin: 100px;
            cursor: pointer;
            background-color: red;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }


        /* link and link-parent */

        .link-parent {
            display: none;
            justify-content: center;
            align-items: center;
            transition: all .3s;
        }

        .link-item {
            margin: -150px;
            background-color: black;
            display: block;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 5px;
            transform: translatey(5px);
            display: flex;
            justify-content: center;
            align-items: center;
            animation-name: move-up;
            animation-duration: .3s;
            animation-timing-function: ease-in;
            animation-iteration-count: 1;
            animation-fill-mode: forwards;
        }


        /* control click */

        #btn:checked~.link-parent {
            display: flex;
            flex-direction: column;
        }


        /* animation */

        @keyframes move-up {
            0% {
                transform: translateY(5px);
            }

            33% {
                transform: translateY(0px);
            }

            66% {
                transform: translateY(-5px);
            }

            100% {
                transform: translateY(0px);
            }
        }

        #link-one {
            animation-delay: .1s;
            margin-left: -320px;
            margin-top: -100px;
            color: #fff;
        }

        #link-two {
            animation-delay: .2s;
            margin-left: -380px;
            margin-top: 50px;
            color: #fff;
        }
    </style>
   

</head>

<body>
    <div class="container">

        <div class="left-container">
            <div class="gauche">
                <?php include "profil.php";
                ?>

                <?php include "double.php";
                ?>

                <?php include "competence.php";
                ?>
            </div>

        </div>


        <div class="right-container">
            <div class="experience">
                <div class="expertise">
                    <?php  include "en_tete.php";
                   ?>

                    <?php  include "dessous.php";
                   ?>

                </div>

                <?php  include "loisirs.php";
                   ?>
            </div>

            <?php  include "cursus.php";
                   ?>



        </div>

    </div>

</body>

</html>