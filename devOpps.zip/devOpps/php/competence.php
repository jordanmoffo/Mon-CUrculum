<?php 
 class competence{
public $front_end;
public $langage;
public $back_end;
public $langage_11;
public $devmobile;
public $langage_111;
public $ux;
public $photo;
public $base_donnees;
public $oracle;
public $outil;
public $visual;

function __construct($front_end,$langage,$back_end,$langage_11,$devmobile,$langage_111,$ux,$photo,$base_donnees,$oracle,$outil,$visual)
{
    $this->front_end=$front_end;
    $this->langage=$langage;
    $this->back_end=$back_end;
    $this->langage_11=$langage_11;
    $this->devmobile=$devmobile;
    $this->langage_111=$langage_111;
    $this->ux=$ux;
    $this->photo=$photo;
    $this->base_donnees=$base_donnees;
    $this->oracle=$oracle;
    $this->outil=$outil;
    $this->visual=$visual;
}
function get_front_end(){
return	$this->front_end;
 }
 function get_langage(){
	return $this->langage;
 }
  function get_back_end(){
return	 $this->back_end;
 }
  function get_langage_11(){
	return $this->langage_11;
 }
  function get_devmobile(){
	return $this->devmobile;
 }
  function get_langage_111(){
	return $this->langage_111;
 }
  function get_ux(){
return	 $this->ux;
 }
  function get_photo(){
	return $this->photo;
 }
  function get_base_donnees(){
	return $this->base_donnees;
 }
  function get_oracle(){
	return $this->oracle;
 }
  function get_outil(){
	return $this->outil;
  }
   function get_visual(){
	return $this->visual;
 }
 }
 $competence=new competence("Développement front-end","HTML5, SASS , VueJS , JavaFX ,...","Développement back-end","NodeJS,Drupal 8,Laravel,Koltin,Java EE 7",
"Développement Mobile","Android Koltin,IOS Swift,Corrdowa,Flutter","UI/UX Design","Photoshop CC,Adobe XD,Material Design","Base de données & Big Data",
 "Oracle 11g,PostgreSQL,Hadoop,Talend DI","Outils/Environnements","Visual Paradigm,Git,Docker,k8s,Linux");
 ?>


<div class="competence">
                    <div class="mon_symbole">
                        <div class="comp1">
                            <div>
                                </p><img src="../image/check.png" class="check"></p>
                            </div>
                            <div>
                                <ol>
                                    <li><strong><?php echo $competence->get_front_end();?></strong></li>
                                    <li><?php echo $competence->get_langage();?></li>
                                </ol>
                            </div>
                            <div class="star">
                                <img src="../image/star.png" class="ign1" />
                            </div>

                        </div>
                        <div>

                            <p class="num3"><input style="width: 85%" type="range" max=100 value="85"></p>
                        </div>
                    </div>

                    <div class="mon_symbole">
                        <div class="comp1">
                            <div>
                                </p><img src="../image/check.png" class="check"></p>
                            </div>
                            <div>
                                <ol>
                                    <li><strong><?php echo $competence->get_back_end();?></strong></li>
                                    <li><?php echo $competence->get_langage_11();?></li>
                                </ol>
                            </div>
                            <div class="star">
                                <img src="../image/star.png" class="ign1" />
                            </div>

                        </div>
                        <div>

                            <p class="num3"><input style="width: 85%" type="range" max=100 value="60"></p>
                        </div>
                    </div>

                    <div class="mon_symbole">
                        <div class="comp1">
                            <div>
                                </p><img src="../image/check.png" class="check"></p>
                            </div>
                            <div>
                                <ol>
                                    <li><strong><?php echo $competence->get_devmobile();?></strong></li>
                                    <li><?php echo $competence->get_langage_111();?></li>
                                </ol>
                            </div>
                            <div class="star">
                                <img src="../image/star.png" class="ign1" />
                            </div>

                        </div>
                        <div>

                            <p class="num3"><input style="width: 85%" type="range" max=100 value="80"></p>
                        </div>
                    </div>


                    <div class="mon_symbole">
                        <div class="comp1">
                            <div>
                                </p><img src="../image/check.png" class="check"></p>
                            </div>
                            <div>
                                <ol>
                                    <li><strong><?php echo $competence->get_ux();?></strong></li>
                                    <li><?php echo $competence->get_photo();?></li>
                                </ol>
                            </div>
                            <div class="star">
                                <img src="../image/star.png" class="ign1" />
                            </div>

                        </div>
                        <div>

                            <p class="num3"><input style="width: 85%" type="range" max=100 value="55"></p>
                        </div>
                    </div>


                    <div class="mon_symbole">
                        <div class="comp1">
                            <div>
                                </p><img src="../image/check.png" class="check"></p>
                            </div>
                            <div>
                                <ol>
                                    <li><strong><?php echo $competence->get_base_donnees();?></strong></li>
                                    <li><?php echo $competence->get_oracle();?></li>
                                </ol>
                            </div>
                            <div class="star">
                                <img src="../image/star.png" class="ign1" />
                            </div>

                        </div>
                        <div>

                            <p class="num3"><input style="width: 85%" type="range" max=100 value="88"></p>
                        </div>
                    </div>

                    <div class="mon_symbole">
                        <div class="comp1">
                            <div>
                                </p><img src="../image/check.png" class="check"></p>
                            </div>
                            <div>
                                <ol>
                                    <li><strong><?php echo $competence->get_outil();?></strong></li>
                                    <li><?php echo $competence->get_visual();?></li>
                                </ol>
                            </div>
                            <div class="star">
                                <img src="../image/star.png" class="ign1" />
                            </div>

                        </div>
                        <div>

                            <p class="num3"><input style="width: 85%" type="range" max=100 value="82"></p>
                        </div>
                    </div>


                </div>
            